# Model for info and sales features
