# Model for only sales features
